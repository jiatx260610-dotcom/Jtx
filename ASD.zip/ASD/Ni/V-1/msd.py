import numpy as np

def calculate_diffusion():
    try:
        # 读取 msd.dat，跳过前两行，提取第1列和第2列
        data = np.loadtxt('msd.dat', skiprows=2, usecols=(0, 1))

        time_ps = data[:, 0]  # 时间，单位 ps
        msd_raw = data[:, 1]  # 原始 MSD，单位 Å²

        # 将 MSD 乘以 3999
        msd_scaled = msd_raw * 3999  # 单位仍是 Å²

        # 线性拟合：y = slope * x + b
        slope, intercept = np.polyfit(time_ps, msd_scaled, 1)

        # 计算扩散系数（单位 m²/s），3D: D = slope / 6 * 1e-20
        D = (slope / 6) * 1e-20

        # 写入结果文件
        with open("diffusion", "w") as f:
            f.write(f"扩散系数 D = {D:.6e} m²/s\n")

        print(f"✅ 扩散系数计算完成，D = {D:.6e} m²/s，结果已写入 diffusion 文件")

    except Exception as e:
        print(f"❌ 错误：{e}")

if __name__ == '__main__':
    calculate_diffusion()
