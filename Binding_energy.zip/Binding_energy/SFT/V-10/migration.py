import os
import shutil

def split_defect_dump():
    total_dir = os.path.join(os.getcwd(), "Total")
    defect_path = os.path.join(total_dir, "defect.dump")
    perfect_path = os.path.join(total_dir, "perfect.data")

    if not os.path.exists(defect_path):
        print("❌ 找不到 defect.dump 文件")
        return
    if not os.path.exists(perfect_path):
        print("❌ 找不到 perfect.data 文件")
        return

    with open(defect_path, "r") as f:
        lines = f.readlines()

    header = lines[:9]
    atom_lines = lines[9:]
    num_atoms = len(atom_lines)

    for i in range(1, num_atoms + 1):
        folder_name = str(i)
        os.makedirs(folder_name, exist_ok=True)

        # 复制 perfect.data
        shutil.copy(perfect_path, os.path.join(folder_name, "perfect.data"))

        # 写入裁剪后的 defect.dump
        new_defect_path = os.path.join(folder_name, "defect.dump")
        with open(new_defect_path, "w") as f:
            f.writelines(header)
            f.write(atom_lines[i - 1])  # 写入对应第 i 个原子的行

        print(f"✅ 已创建 {folder_name} 文件夹并写入对应原子数据")

if __name__ == "__main__":
    split_defect_dump()
