def calculate_formation_energy():
    # 定义内聚能映射
    cohesive_energy_map = {
        '1': -4.40559272487553,  # Co
        '2': -4.45000000000362,  # Ni
        '3': -4.24209920915967,  # Fe
        '4': -4.01301310002497,  # Cr
        '5': -2.9090040525822    # Mn
    }

    try:
        # Step 1: 获取 differ.dat 第一行第一个数值
        with open('differ.dat', 'r') as f:
            first_line = f.readline()
            base_energy = float(first_line.strip().split()[0])

        # Step 2: 读取 defect.dump，跳过前 9 行
        with open('defect.dump', 'r') as f:
            lines = f.readlines()[9:]

        # Step 3: 遍历剩余行，根据第二列原子类型求和内聚能
        total_cohesive_energy = 0.0
        for line in lines:
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            atom_type = parts[1]
            if atom_type in cohesive_energy_map:
                total_cohesive_energy += cohesive_energy_map[atom_type]

        # Step 4: 形成能 = 能量差 + 总内聚能
        formation_energy = base_energy + total_cohesive_energy

        # Step 5: 写入 formation 文件（仅写数值）
        with open('formation', 'w') as f:
            f.write(f"{formation_energy:.10f}\n")

        print(f"✅ 形成能已写入 formation 文件：{formation_energy:.10f}")

    except Exception as e:
        print(f"❌ 出现错误: {e}")

if __name__ == '__main__':
    calculate_formation_energy()
