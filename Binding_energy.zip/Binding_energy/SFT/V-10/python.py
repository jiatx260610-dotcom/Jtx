import os
import subprocess

def run_formation_scripts():
    base_dir = os.getcwd()
    numeric_dirs = sorted([d for d in os.listdir(base_dir) if os.path.isdir(d) and d.isdigit()],
                          key=lambda x: int(x))

    for folder in numeric_dirs:
        folder_path = os.path.join(base_dir, folder)
        script_path = os.path.join(folder_path, "formation.py")

        if os.path.exists(script_path):
            print(f"🚀 正在运行 {folder}/formation.py")
            try:
                subprocess.run(["python", "formation.py"], cwd=folder_path, check=True)
                print(f"✅ 成功运行 {folder}/formation.py")
            except subprocess.CalledProcessError as e:
                print(f"❌ 运行失败: {folder}/formation.py\n  错误: {e}")
        else:
            print(f"⚠️ 跳过 {folder}：未找到 formation.py")

if __name__ == "__main__":
    run_formation_scripts()
