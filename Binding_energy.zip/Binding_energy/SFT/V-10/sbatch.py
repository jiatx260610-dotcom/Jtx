import os
import subprocess

def submit_lammps_jobs():
    base_dir = os.getcwd()
    # 获取纯数字命名的文件夹并排序
    numeric_dirs = sorted([d for d in os.listdir(base_dir) if os.path.isdir(d) and d.isdigit()],
                          key=lambda x: int(x))

    for folder in numeric_dirs:
        folder_path = os.path.join(base_dir, folder)
        lammps_script = os.path.join(folder_path, "lammps.sh")

        if os.path.exists(lammps_script):
            print(f"📡 正在提交 {folder}/lammps.sh ...")
            try:
                subprocess.run(["sbatch", "lammps.sh"], cwd=folder_path, check=True)
                print(f"✅ 成功提交 {folder}/lammps.sh")
            except subprocess.CalledProcessError as e:
                print(f"❌ 提交失败: {folder}/lammps.sh\n  错误: {e}")
        else:
            print(f"⚠️ 跳过 {folder}：未找到 lammps.sh 文件")

if __name__ == "__main__":
    submit_lammps_jobs()
