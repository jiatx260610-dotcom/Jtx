import os

def compute_binding_energy():
    base_dir = os.getcwd()

    # 获取所有以纯数字命名的文件夹，并排序
    numeric_dirs = sorted([d for d in os.listdir(base_dir) if os.path.isdir(d) and d.isdigit()],
                          key=lambda x: int(x))

    total_formation_energy_1 = 0.0

    for folder in numeric_dirs:
        formation_path = os.path.join(base_dir, folder, "formation")
        if os.path.exists(formation_path):
            with open(formation_path, "r") as f:
                line = f.readline().strip()
                try:
                    energy = float(line)
                    total_formation_energy_1 += energy
                except ValueError:
                    print(f"⚠️ 警告：无法解析 {formation_path} 中的数值，内容为：{line}")
        else:
            print(f"⚠️ 警告：未找到 {formation_path}")

    # 获取 Total 文件夹下的 formation 文件
    total_dir = os.path.join(base_dir, "Total")
    total_formation_path = os.path.join(total_dir, "formation")

    if not os.path.exists(total_formation_path):
        print("❌ 错误：未找到 Total/formation 文件")
        return

    with open(total_formation_path, "r") as f:
        try:
            total_formation_energy_2 = float(f.readline().strip())
        except ValueError:
            print("❌ 错误：Total/formation 中内容无法解析")
            return

    # 计算结合能
    binding_energy = total_formation_energy_1 - total_formation_energy_2

    # 写入 binding 文件
    with open(os.path.join(base_dir, "binding"), "w") as f:
        f.write(f"{binding_energy:.10f}\n")

    print(f"✅ 结合能已写入 binding 文件，数值为：{binding_energy:.10f}")

if __name__ == "__main__":
    compute_binding_energy()
