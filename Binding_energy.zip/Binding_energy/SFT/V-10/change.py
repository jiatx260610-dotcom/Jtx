import os

def update_in_HEAs_files():
    base_dir = os.getcwd()
    numeric_dirs = sorted([d for d in os.listdir(base_dir) if os.path.isdir(d) and d.isdigit()],
                          key=lambda x: int(x))

    for folder in numeric_dirs:
        folder_path = os.path.join(base_dir, folder)
        defect_path = os.path.join(folder_path, "defect.dump")
        heas_path = os.path.join(folder_path, "in.HEAs")

        # 检查文件存在
        if not os.path.exists(defect_path):
            print(f"❌ {folder}/defect.dump 不存在，跳过")
            continue
        if not os.path.exists(heas_path):
            print(f"❌ {folder}/in.HEAs 不存在，跳过")
            continue

        # 提取 defect.dump 第10行第一列数值
        with open(defect_path, 'r') as f:
            lines = f.readlines()
        if len(lines) < 10:
            print(f"⚠️ {folder}/defect.dump 行数不足 10，跳过")
            continue

        try:
            atom_id = lines[9].split()[0]  # 第10行第一列
        except IndexError:
            print(f"⚠️ {folder}/defect.dump 第10行格式错误，跳过")
            continue

        # 修改 in.HEAs 第22行 id 后面的数值
        with open(heas_path, 'r') as f:
            heas_lines = f.readlines()

        if len(heas_lines) < 22:
            print(f"⚠️ {folder}/in.HEAs 行数不足 22，跳过")
            continue

        parts = heas_lines[21].split()
        if "id" in parts:
            id_index = parts.index("id")
            if id_index + 1 < len(parts):
                parts[id_index + 1] = atom_id
                heas_lines[21] = " ".join(parts) + "\n"
            else:
                print(f"⚠️ {folder}/in.HEAs 第22行格式错误，跳过")
                continue
        else:
            print(f"⚠️ {folder}/in.HEAs 第22行未包含 'id'，跳过")
            continue

        # 写回修改后的 in.HEAs
        with open(heas_path, 'w') as f:
            f.writelines(heas_lines)

        print(f"✅ 已更新 {folder}/in.HEAs 中 id 为 {atom_id}")

if __name__ == "__main__":
    update_in_HEAs_files()
