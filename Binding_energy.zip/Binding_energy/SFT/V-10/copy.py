import os
import shutil

# 要复制的文件列表
files_to_copy = ["CoNiCrFeMn.meam", "formation.py", "in.HEAs", "lammps.sh", "library.meam"]

# 获取当前目录
current_dir = os.getcwd()

# 遍历当前目录下所有文件夹
for item in os.listdir(current_dir):
    item_path = os.path.join(current_dir, item)
    if os.path.isdir(item_path) and item.isdigit():
        for file in files_to_copy:
            if os.path.exists(file):
                dst = os.path.join(item_path, file)
                shutil.copy(file, dst)
                print(f"✅ 已复制 {file} 到文件夹 {item}")
            else:
                print(f"⚠️ 文件 {file} 不存在，跳过复制。")
