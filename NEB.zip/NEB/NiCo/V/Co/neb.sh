#!/bin/bash
#SBATCH --job-name=LAMMPS
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=11
#SBATCH -c 1
#SBATCH --partition=xahcnormal

ulimit -s unlimited
module purge
module load  lammps/22Aug18-intelmpi-2017 

###in.lj为输入文件，可自行更改###
srun -n 11  --mpi=pmi2 lmp_intel_cpu_intelmpi -partition 11x1 -in in.neb