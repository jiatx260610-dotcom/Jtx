import os
import re
import math

# 获取当前工作目录
base_path = os.getcwd()

# 创建result文件夹
result_dir = os.path.join(base_path, "result")
os.makedirs(result_dir, exist_ok=True)

# 输出文件路径
output_file_path = os.path.join(result_dir, "Total.txt")

# 关键词
keywords = ["Setting up regular NEB ...", "srun: ROUTE:"]

# NEB文件夹路径
neb_dir = os.path.join(base_path, "NEB")

# 获取NEB文件夹中所有子文件夹
neb_subfolders = [os.path.join(neb_dir, folder) for folder in os.listdir(neb_dir) if os.path.isdir(os.path.join(neb_dir, folder))]

# 遍历各个子文件夹，查找以"slurm"开头的文件
for subfolder in neb_subfolders:
    slurm_files = [filename for filename in os.listdir(subfolder) if filename.startswith("slurm")]
    
    # 遍历符合条件的文件
    for slurm_file in slurm_files:
        slurm_file_path = os.path.join(subfolder, slurm_file)

        # 打开文件并逐行读取
        with open(slurm_file_path, 'r') as file:
            lines = file.readlines()

        # 遍历文件内容
        for idx, line in enumerate(lines):
            # 检查关键词是否存在
            if any(keyword in line for keyword in keywords) and idx > 0:
                # 获取上一行内容的第一列
                previous_line_first_column = lines[idx - 1].split()[0]

                # 判断第一列是否是数值
                if previous_line_first_column.strip().replace("-", "").isdigit():
                    # 将提取的内容写入文件
                    with open(output_file_path, 'a') as output_file:
                        output_file.write(lines[idx - 1])

print("Total文件完成！")

# 输入文件名
input_filename = "Total.txt"

# 输出文件名
output_filename = "Path.txt"

# 输入文件路径
input_file_path = os.path.join(result_dir, input_filename)

# 输出文件路径
output_file_path = os.path.join(result_dir, output_filename)

# 打开输入文件并读取内容
with open(input_file_path, 'r') as input_file:
    lines = input_file.readlines()

# 打开输出文件并写入内容
with open(output_file_path, 'w') as output_file:
    for line in lines:
        # 按空格分隔每一行，并提取最后22列
        last_22_columns = line.split()[-22:]

        # 将提取的内容写入输出文件
        output_file.write(" ".join(last_22_columns) + "\n")

print("Path文件完成！")

# 输入文件名
input_filename = "Path.txt"

# 输出文件名
output_filename = "Energy.txt"

# 输入文件路径
input_file_path = os.path.join(result_dir, input_filename)

# 输出文件路径
output_file_path = os.path.join(result_dir, output_filename)

# 打开输入文件并读取内容
with open(input_file_path, 'r') as input_file:
    lines = input_file.readlines()

# 打开输出文件并写入内容
with open(output_file_path, 'w') as output_file:
    for line in lines:
        # 按空格分隔每一行，并提取偶数列的数值
        even_columns_values = [float(value) for idx, value in enumerate(line.split(), start=1) if idx % 2 == 0]

        # 对偶数列的数值进行处理（最大值减去最小值）
        if even_columns_values:
            result_value = max(even_columns_values) - min(even_columns_values)
        else:
            result_value = 0.0  # 如果没有偶数列的数值，则结果为0.0

        # 判断处理后的结果是否在指定范围内，如果是，则写入输出文件
        if 0.05 <= result_value <= 2:
            output_file.write(str(result_value) + "\n")

print("势垒处理完成！")

# 输入文件名
input_filename = "Energy.txt"

# 输出文件名
output_filename = "Results.txt"

# 输入文件路径
input_file_path = os.path.join(result_dir, input_filename)

# 输出文件路径
output_file_path = os.path.join(result_dir, output_filename)

# 打开输入文件并读取内容
with open(input_file_path, 'r') as input_file:
    lines = input_file.readlines()

# 选择性地排除数值大于1或小于0.05的数据
filtered_values = [float(line.strip()) for line in lines if 0.05 <= float(line.strip()) <= 1.5]

# 如果没有符合条件的数据，则输出提示信息
if not filtered_values:
    print("没有符合条件的数据。")
else:
    # 计算平均值和偏差
    average_value = sum(filtered_values) / len(filtered_values)

    # 计算偏差
    deviation = math.sqrt(sum((value - average_value) ** 2 for value in filtered_values) / len(filtered_values))

    # 打开输出文件并写入内容
    with open(output_file_path, 'w') as output_file:
        # 写入平均值和偏差
        output_file.write("Average: {}\n".format(average_value))
        output_file.write("Deviation: {}\n".format(deviation))

print("计算完成！")
