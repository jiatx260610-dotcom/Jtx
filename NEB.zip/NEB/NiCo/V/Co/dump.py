import os

def process_final_dump_files():
    # 定义NEB文件夹路径
    neb_dir = os.path.join(".", "NEB")
    
    # 检查NEB文件夹是否存在
    if not os.path.exists(neb_dir):
        print("NEB 文件夹不存在。")
        return

    # 获取NEB文件夹中的所有子文件夹
    folders = [folder for folder in os.listdir(neb_dir) if os.path.isdir(os.path.join(neb_dir, folder))]

    # 遍历每个子文件夹
    for folder in folders:
        folder_path = os.path.join(neb_dir, folder)
        final_dir = os.path.join(folder_path, "final")

        # 检查final文件夹是否存在
        if os.path.exists(final_dir) and os.path.isdir(final_dir):
            # 获取final文件夹中的所有final.*.dump文件
            dump_files = [f for f in os.listdir(final_dir) if f.startswith("final.") and f.endswith(".dump")]
            
            for dump_file in dump_files:
                dump_file_path = os.path.join(final_dir, dump_file)
                
                # 读取文件内容
                with open(dump_file_path, 'r') as file:
                    lines = file.readlines()

                # 删除1到3行和5到9行的内容
                processed_lines = [line for i, line in enumerate(lines) if i not in range(0, 3) and i not in range(4, 9)]

                # 将处理后的内容写回文件
                with open(dump_file_path, 'w') as file:
                    file.writelines(processed_lines)
               

# 调用函数执行操作
process_final_dump_files()
