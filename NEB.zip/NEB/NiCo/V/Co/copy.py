import os
import shutil

# 定义要复制的文件和目标目录
files_to_copy = ['CoNiCrFeMn.meam', 'in.neb', 'library.meam', 'neb.sh']
target_dir = 'NEB'

# 检查目标目录是否存在
if not os.path.exists(target_dir):
    print(f"目标目录 {target_dir} 不存在。")
    exit(1)

# 获取目标目录中的所有子文件夹
subfolders = [f.path for f in os.scandir(target_dir) if f.is_dir()]

# 将文件复制到每个子文件夹中
for subfolder in subfolders:
    for file in files_to_copy:
        if os.path.exists(file):
            shutil.copy(file, subfolder)
        else:
            print(f"文件 {file} 不存在，跳过。")
