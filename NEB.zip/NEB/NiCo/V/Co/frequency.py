import os
import math
from collections import defaultdict

def analyze_energy_distribution():
    energy_path = os.path.join('result', 'Energy.txt')
    if not os.path.exists(energy_path):
        print("❌ 未找到 result/Energy.txt")
        return

    values = []
    with open(energy_path, 'r') as f:
        for line in f:
            tokens = line.strip().split()
            if tokens:
                try:
                    val = float(tokens[0])
                    values.append(val)
                except ValueError:
                    continue

    if not values:
        print("⚠️ 没有有效的数值可用于分析")
        return

    # 分类统计：向上取整到最近的 0.1
    bin_counts = defaultdict(int)
    total = len(values)

    for v in values:
        if v < 0:
            continue  # 可选：跳过负数
        bin_key = math.ceil(v * 10) / 10
        bin_counts[bin_key] += 1

    # 排序输出并写入 energy_frequency.txt
    output_lines = ["范围上界\t频率\n"]
    for key in sorted(bin_counts):
        freq = bin_counts[key] / total
        line = f"{key:.1f}\t{freq:.6f}\n"
        output_lines.append(line)

    # 写入文件
    with open("energy_frequency.txt", 'w') as f_out:
        f_out.writelines(output_lines)

    print("✅ 频率结果已写入 energy_frequency.txt")
    print("范围上界\t频率")
    print("".join(output_lines[1:]))

if __name__ == '__main__':
    analyze_energy_distribution()
