#!/bin/bash
#SBATCH --job-name=LAMMPS
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=64
#SBATCH -c 1
#SBATCH --partition=xahcnormal

ulimit -s unlimited
module purge
module load lammps/28Mar2023-intel_21

###in.lj为输入文件，可自行更改###
mpirun -np 64 lmp_mpi -i in.HEAs