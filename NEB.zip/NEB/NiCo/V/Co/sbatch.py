import os

def submit_jobs_in_folders():
    try:
        # 定义NEB文件夹路径
        neb_dir = os.path.join(".", "NEB")
        
        # 检查NEB文件夹是否存在
        if not os.path.exists(neb_dir):
            return "NEB 文件夹不存在。"

        # 获取NEB文件夹中的所有子文件夹
        folders = [folder for folder in os.listdir(neb_dir) if os.path.isdir(os.path.join(neb_dir, folder))]

        # 遍历每个子文件夹，并执行 sbatch 命令
        for folder in folders:
            folder_path = os.path.join(neb_dir, folder)
            # 构建进入文件夹的命令
            cd_command = f"cd {folder_path}"
            # 执行 sbatch 命令
            sbatch_command = "sbatch neb.sh"
            # 组合命令
            full_command = f"{cd_command} && {sbatch_command}"
            # 使用 os.system 执行命令
            os.system(full_command)
            print(f"Jobs submitted in folder '{folder_path}'.")

        return "All jobs submitted successfully."
    except Exception as e:
        return f"An error occurred: {e}"

# 调用函数执行操作
print(submit_jobs_in_folders())
